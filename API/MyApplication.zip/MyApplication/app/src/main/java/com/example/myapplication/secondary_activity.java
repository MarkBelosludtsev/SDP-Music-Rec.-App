package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class secondary_activity extends AppCompatActivity {

    Button back, addSong;
    EditText id, title, artist, album, genre, length;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_secondary_activity);

        back = findViewById(R.id.backButton);
        id = findViewById(R.id.idTextBox);
        title = findViewById(R.id.titleTextBox);
        artist = findViewById(R.id.artistTextBox);
        album = findViewById(R.id.albumTextBox);
        genre = findViewById(R.id.genreTextBox);
        length = findViewById(R.id.lengthTextBox);
        addSong = findViewById(R.id.addSongButton);


        back.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Intent i = new Intent(secondary_activity.this, MainActivity.class);
                startActivity(i);
            }
        });

        addSong.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Database songDatabase = new Database(secondary_activity.this);

                Song newSong = new Song(Integer.parseInt(id.getText().toString()), title.getText().toString(), artist.getText().toString(), album.getText().toString(),
                        genre.getText().toString(), Integer.parseInt(length.getText().toString()), "none");

                if (songDatabase.addSong(newSong))
                    Toast.makeText(secondary_activity.this, "Successfully Added", Toast.LENGTH_LONG).show();
            }
        });
    }
}