package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

//ADDED
import java.util.ArrayList;
import android.util.Log;

import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.JSONArrayRequestListener;

import org.json.JSONArray;

public class MainActivity extends AppCompatActivity {
    DrawerLayout drawerLayout;//ADDED

    Button search, delete, viewAll, addSong;
    EditText songEntry;
    TextView appHeader, songInfo;
    ListView songList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        search = findViewById(R.id.searchButton);
        delete = findViewById(R.id.deleteButton);
        viewAll = findViewById(R.id.viewAllButton);
        appHeader = findViewById(R.id.mainSongListLabel);
        songInfo = findViewById(R.id.songInfoLabel);
        songEntry = findViewById(R.id.songNameTextBox);
        //songList = findViewById(R.id.mainDatabaseList);
        addSong = findViewById(R.id.addButton);

        ListView mListView = (ListView) findViewById(R.id.listView);

        Database songDatabase = new Database(MainActivity.this);

        //showSongsOnListView(songDatabase);


        search.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Database songDatabase = new Database(MainActivity.this);
                String name = songEntry.getText().toString();

                Song result= songDatabase.findSong(name);

                if (result.getTitle()=="none")
                    Toast.makeText(MainActivity.this, "Song was not found", Toast.LENGTH_LONG).show();
                else
                {
                    songInfo.setText(result.toString());
                    Toast.makeText(MainActivity.this, "Song was found", Toast.LENGTH_LONG).show();
                }
            }
        });

        viewAll.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Database songDatabase = new Database(MainActivity.this);
                List<Song> allSongs = songDatabase.getAllSongs();

                //showSongsOnListView(songDatabase);

                //Toast.makeText(MainActivity.this, allSongs.toString(), Toast.LENGTH_LONG).show();

                AndroidNetworking.get("https://PLACEHOLDER")//fierce-cove-29863.herokuapp.com/getAllUsers/{pageNumber}
                        .addPathParameter("pageNumber", "0")
                        .addQueryParameter("limit", "3")
                        .addHeaders("token", "1234")
                        .setTag("test")
                        //.setPriority(Priority.LOW)
                        .build()
                        .getAsJSONArray(new JSONArrayRequestListener() {
                            @Override
                            public void onResponse(JSONArray response) {
                                // do anything with response
                            }
                            @Override
                            public void onError(ANError error) {
                                // handle error
                            }
                        });
                Toast.makeText(MainActivity.this, "GET request sent!", Toast.LENGTH_LONG).show();
            }
        });

        addSong.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Intent i = new Intent(MainActivity.this,secondary_activity.class);
                startActivity(i);
            }
        });

        delete.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Database songDatabase = new Database(MainActivity.this);
                String name = songEntry.getText().toString();

                Song result= songDatabase.findSong(name);

                if (result.getTitle()=="none")
                    Toast.makeText(MainActivity.this, "Song was not found", Toast.LENGTH_LONG).show();
                else
                {
                    songDatabase.deleteSong(result);
                    Toast.makeText(MainActivity.this, "Song deleted", Toast.LENGTH_LONG).show();
                }
            }
        });




        SongListAdapter adapter = new SongListAdapter(this, R.layout.adapter_view_layout, songDatabase.getAllSongs());
        mListView.setAdapter(adapter);
        //Assign variable
        drawerLayout = findViewById(R.id.drawer_layout);
    }

    private void showSongsOnListView(Database db)
    {
        ArrayAdapter songArrayAdapter = new ArrayAdapter<Song>(MainActivity.this, android.R.layout.simple_list_item_1, db.getAllSongs());
        songList.setAdapter(songArrayAdapter);

    }


    //ADDED START
    public void ClickMenu(View view){
        //open drawer
        openDrawer(drawerLayout);
    }

    public static void openDrawer(DrawerLayout drawerLayout) {
        //Open drawer layout
        drawerLayout.openDrawer(GravityCompat.START);
    }

    public void ClickLogo(View view){
        //Close drawer
        closeDrawer(drawerLayout);
    }

    public static void closeDrawer(DrawerLayout drawerLayout) {
        //Close drawer layout
        //check condition
        if (drawerLayout.isDrawerOpen(GravityCompat.START)){
            //when drawer is open
            //close drawer
            drawerLayout.closeDrawer(GravityCompat.START);
        }
    }

    public void ClickHome(View view){
        //recreate activity
        recreate();
    }

    public void ClickSettings(View view){
        //redirect activity to dashboard
        redirectActivity(this,Settings.class);
    }

    public void ClickLibrary(View view){
        //redirect activity to dashboard
        redirectActivity(this, Library2.class);
    }

    public void ClickAboutUs(View view){
        //redirect activity to about us
        redirectActivity(this,AboutUs.class);
    }

    public void ClickLogout(View view){
        //close app
        logout(this);
    }

    public static void logout(final Activity activity) {
        //initialize alert dialog
        AlertDialog.Builder builder = new AlertDialog.Builder(activity);
        //set title
        builder.setTitle("Logout");
        //set message
        builder.setMessage("Are you sure you want to logout?");
        //positive yes button
        builder.setPositiveButton("YES", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                //finish activity
                activity.finishAffinity();
                //Exit app
                System.exit(0);
            }
        });
        //negative no button
        builder.setNegativeButton("NO", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                //dismiss dialog
                dialog.dismiss();
            }
        });
        //show dialog
        builder.show();
    }

    public static void redirectActivity(Activity activity, Class aClass) {
        //Initialize intent
        Intent intent = new Intent (activity,aClass);
        //set flag
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        //Start activity
        activity.startActivity(intent);

    }

    @Override
    protected void onPause() {
        super.onPause();
        //close drawer
        closeDrawer(drawerLayout);
    }
    //ADDED END
}