package com.example.navdrawer;

import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;

import android.os.Bundle;
import android.view.View;

public class AboutUs extends AppCompatActivity {
    //initialize variable
    DrawerLayout drawerLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about_us);

        //assign variable
        drawerLayout = findViewById(R.id.drawer_layout);
    }

    public void ClickMenu(View view){
        //open drawer
        MainActivity.openDrawer(drawerLayout);

    }
    public void ClickLogo(View view){
        //close drawer
        MainActivity.closeDrawer(drawerLayout);
    }

    public void ClickHome(View view){
        //redirect activity to home
        MainActivity.redirectActivity(this, MainActivity.class);
    }

    public void ClickLibrary(View view){
        //redirect activity to dashboard
        MainActivity.redirectActivity(this,Library2.class);
    }

    public void ClickSettings(View view){
        //redirect activity to settings
        MainActivity.redirectActivity(this,Settings.class);
    }

    public void ClickSongEntry(View view){
        //redirect activity to dashboard
        MainActivity.redirectActivity(this, SongEntry.class);
    }

    public void ClickResults(View view){
        //redirect activity to dashboard
        MainActivity.redirectActivity(this, Results.class);
    }

    public void ClickRecentPlaylists(View view){
        //redirect activity to dashboard
        MainActivity.redirectActivity(this, RecentPlaylists.class);
    }

    public void ClickAboutUs (View view){
        //recreate activity
        recreate();
    }

    public void ClickLogout(View view){
        //close app
        MainActivity.logout(this);
    }

    @Override
    protected void onPause() {
        super.onPause();
        //close drawer
        MainActivity.closeDrawer(drawerLayout);
    }
}