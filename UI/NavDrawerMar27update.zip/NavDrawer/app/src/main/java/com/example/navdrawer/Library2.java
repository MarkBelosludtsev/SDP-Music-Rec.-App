package com.example.navdrawer;

import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.ViewCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import java.util.ArrayList;

public class Library2 extends AppCompatActivity {
    //Initialize variable
    DrawerLayout drawerLayout;

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_library2);

        // comment from here
        ListView mListView = (ListView) findViewById(R.id.listView);

        //song objects
        Song RicFlairDrip = new Song ("Ric Flair Drip", "Offset, Metro Boomin", "Without Warning", "Rap/Hip-Hop","2:53");
        Song Skeletons = new Song ("SKELETONS", "Travis Scott", "ASTROWORLD", "Rap/Hip-Hop","2:26");
        Song TooLate = new Song ("Too Late", "The Weeknd", "After Hours", "R&B/Soul","4:00");
        Song TheWeekend = new Song ("The Weekend", "SZA", "Ctrl", "R&B/Soul","4:32");
        Song Heartless = new Song ("Heartless", "Kanye West", "808s and Heartbreak", "Rap/Hip-Hop","3:31");
        Song LOYAL = new Song ("LOYAL", "PARTYNEXTDOOR, Drake", "PARTYMOBILE", "R&B/Soul", "3:17");
        Song Pedestrian = new Song ("Pedestrian", "Gunna", "Drip Season 3", "Rap/Hip-Hop","3:45");
        Song TheseWalls = new Song ("These Walls", "Kendrick Lamar", "To Pimp a Butterfly", "Rap/Hip-Hop","5:01");
        Song ThoughtItWasADrought = new Song ("Thought It Was a Drought", "Future", "DS2", "Rap/Hip-Hop","4:25");
        Song Impossible = new Song ("Impossible", "Travis Scott", "Rodeo", "Rap/Hip-Hop","4:02");
        Song FML = new Song ("FML", "Kanye West", "The Life of Pablo", "Rap/Hip-Hop","3:56");
        Song Muscles = new Song ("muscles", "TriTip", "VULTURE", "Rap/Hip-Hop","3:38");
        Song BluePill = new Song ("Blue Pill", "Metro Boomin", "Blue Pill", "Rap/Hip-Hop","3:53");
        Song HoldMyLiquor = new Song ("Hold My Liquor", "Kanye West", "Yeezus", "Rap/Hip-Hop","5:27");
        Song Yosemite = new Song ("YOSEMITE", "Travis Scott", "ASTROWORLD", "Rap/Hip-Hop","2:30");

        //array list
        ArrayList<Song> songList = new ArrayList<>();
            songList.add(RicFlairDrip);
            songList.add(Skeletons);
            songList.add(TooLate);
            songList.add(TheWeekend);
            songList.add(Heartless);
            songList.add(LOYAL);
            songList.add(Pedestrian);
            songList.add(TheseWalls);
            songList.add(ThoughtItWasADrought);
            songList.add(Impossible);
            songList.add(FML);
            songList.add(Muscles);
            songList.add(BluePill);
            songList.add(HoldMyLiquor);
            songList.add(Yosemite);

        SongListAdapter adapter = new SongListAdapter(this, R.layout.adapter_view_layout, songList);
        mListView.setAdapter(adapter);   //to here

        //Assign variable
        drawerLayout = findViewById(R.id.drawer_layout);
    }

    public void ClickMenu(View view){
        //open drawer
        MainActivity.openDrawer(drawerLayout);

    }
    public void ClickLogo(View view){
        //close drawer
        MainActivity.closeDrawer(drawerLayout);
    }

    public void ClickHome(View view){
        //redirect activity to home
        MainActivity.redirectActivity(this, MainActivity.class);
    }

    public void ClickLibrary(View view){
        //recreate activity
        recreate();
    }

    public void ClickSettings(View view){
        //redirect activity to settings
        MainActivity.redirectActivity(this,Settings.class);
    }

    public void ClickSongEntry(View view){
        //redirect activity to dashboard
        MainActivity.redirectActivity(this, SongEntry.class);
    }

    public void ClickAboutUs (View view){
        //redirect activity to about us
        MainActivity.redirectActivity(this,AboutUs.class);
    }

    public void ClickLogout(View view){
        //close app
        MainActivity.logout(this);
    }

    @Override
    protected void onPause() {
        super.onPause();
        //close drawer
        MainActivity.closeDrawer(drawerLayout);
    }
}