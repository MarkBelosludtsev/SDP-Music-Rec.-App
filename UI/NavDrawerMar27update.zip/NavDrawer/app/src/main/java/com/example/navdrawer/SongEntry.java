package com.example.navdrawer;

import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.ArrayList;

public class SongEntry extends AppCompatActivity {
    //Initialize variable
    DrawerLayout drawerLayout;

    String songName;
    EditText editTextSongEntry;

    String songName2;
    EditText editTextSongEntry2;

    String songName3;
    EditText editTextSongEntry3;
    Button button2;
    TextView textViewCheck;
    ArrayList<String> seedSongs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_song_entry);

        seedSongs = new ArrayList<>();

        editTextSongEntry = (EditText) findViewById(R.id.editTextSongEntry);
        editTextSongEntry2 = (EditText) findViewById(R.id.editTextSongEntry2);
        editTextSongEntry3 = (EditText) findViewById(R.id.editTextSongEntry3);

        textViewCheck = (TextView) findViewById(R.id.textViewCheck);

        button2 = (Button) findViewById(R.id.button2);
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                songName = editTextSongEntry.getText().toString();
                songName2 = editTextSongEntry2.getText().toString();
                songName3 = editTextSongEntry3.getText().toString();
                seedSongs.add(songName);
                seedSongs.add(songName2);
                seedSongs.add(songName3);
                editTextSongEntry.getText().clear();
                editTextSongEntry2.getText().clear();
                editTextSongEntry3.getText().clear();
                textViewCheck.setText("");

                //THE BELOW CODE CHECKS WHAT IS IN THE "seedSongs" ARRAY
                /*for(int i = 0; i < seedSongs.size(); i++) {
                    textViewCheck.append(seedSongs.get(i));
                    textViewCheck.append("\n");
                }*/
            }
        });

        //Assign variable
        drawerLayout = findViewById(R.id.drawer_layout);
    }



    public void ClickMenu(View view){
        //open drawer
        MainActivity.openDrawer(drawerLayout);

    }
    public void ClickLogo(View view){
        //close drawer
        MainActivity.closeDrawer(drawerLayout);
    }

    public void ClickHome(View view){
        //redirect activity to home
        MainActivity.redirectActivity(this, MainActivity.class);
    }

    public void ClickLibrary(View view){
        //redirect activity to dashboard
        MainActivity.redirectActivity(this, Library2.class);
    }

    public void ClickSettings(View view){
        //redirect activity to settings
        MainActivity.redirectActivity(this,Settings.class);
    }

    public void ClickSongEntry(View view){
        //recreate activity
        recreate();
    }

    public void ClickAboutUs (View view){
        //redirect activity to about us
        MainActivity.redirectActivity(this,AboutUs.class);
    }

    public void ClickLogout(View view){
        //close app
        MainActivity.logout(this);
    }

    @Override
    protected void onPause() {
        super.onPause();
        //close drawer
        MainActivity.closeDrawer(drawerLayout);
    }
}