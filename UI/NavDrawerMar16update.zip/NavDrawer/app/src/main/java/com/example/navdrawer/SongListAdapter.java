package com.example.navdrawer;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

//import androidx.annotation.NonNull;

import androidx.annotation.NonNull;
//import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class SongListAdapter extends ArrayAdapter<Song> {
    private static final String TAG = "SongListAdapter";
    private Context mContext;
    int mResource;

    public SongListAdapter(Context context, int resource, ArrayList<Song> objects) {
        super(context, resource, objects);
        mContext = context;
        mResource = resource;
    }

    @NonNull
    @Override
    public View getView(int position, View convertView,ViewGroup parent) {
        // get song info
        String name = getItem(position).getSong();
        String artist = getItem(position).getArtist();
        String album = getItem(position).getAlbum();
        String genre = getItem(position).getGenre();
        String duration = getItem(position).getDuration();

        //create the song object with info
        Song song = new Song(name,artist,album,genre, duration);

        LayoutInflater inflater = LayoutInflater.from(mContext);
        convertView = inflater.inflate(mResource, parent, false);

        TextView tvName = (TextView) convertView.findViewById(R.id.textViewName);
        TextView tvArtist = (TextView) convertView.findViewById(R.id.textViewArtist);
        TextView tvAlbum = (TextView) convertView.findViewById(R.id.textViewAlbum);
        TextView tvGenre = (TextView) convertView.findViewById(R.id.textViewGenre);
        TextView tvDuration = (TextView) convertView.findViewById(R.id.textViewDuration);

        tvName.setText(name);
        tvArtist.setText(artist);
        tvAlbum.setText(album);
        tvGenre.setText(genre);
        tvDuration.setText(duration);

        return convertView;
    }
}
